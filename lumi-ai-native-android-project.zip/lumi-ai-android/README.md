# LUMI AI — Native Android Studio Project (`com.okolojoyce.lumiai`)

**Creator:** Okolo Joyce Ilemi  
**Brand Identity:** Nigerian-created, built for the world.  
**Tagline:** *Your World, Intelligently Connected.*

---

## 1. What Is Included in This Package

This archive is a complete, authentic **Kotlin + Jetpack Compose** Android Studio project (`minSdk 26`, `targetSdk 35`) designed to pair with your live LUMI AI backend server:

- **Original Lumi Beacon Adaptive Icons & Android 12+ Splash Screen** (`res/drawable/ic_launcher_foreground.xml`, `ic_launcher_background.xml`, `themes.xml`) in Royal Navy (`#060B18`), Warm Gold (`#E5C158`), and Crisp White (`#FFFFFF`).
- **Voice-First Native Companion (`LumiVoiceManager.kt`)**: Tap-to-speak `SpeechRecognizer`, spoken `TextToSpeech` answers, 1-tap `Interrupt & Speak` barge-in, replayable answers, and explicit `WAITING` / `LISTENING` / `PROCESSING` / `SPEAKING` status badges.
- **Safe Native App Launching & Device Intents (`DeviceActionExecutor.kt`)**:
  - Verifies installed apps via Android `PackageManager` (`<queries>` declared in `AndroidManifest.xml` for Android 11+ API 30+ visibility) to launch **WhatsApp**, **YouTube**, **Gmail**, **Google Calendar**, **Google Drive**, **Google Contacts**, **Chrome/Browser**, **Google**, and **Android System Settings** (`android.settings.SETTINGS`).
  - Falls back cleanly to HTTPS browser links if a requested third-party app is not installed.
  - Creates device timers/reminders via `AlarmClock.ACTION_SET_TIMER` and shares message drafts via `Intent.ACTION_SEND` without ever sending messages behind the user's back.
- **Secure Backend Proxy (`LumiApiClient.kt`)**: Calls your deployed LUMI AI server (`/api/chat`) so `GEMINI_API_KEY` remains strictly on the server and is never embedded inside the Android binary.
- **Full Lumi Workspace Tab**: Embedded Compose `WebView` tab giving instant access to your Creative Studio, Google Workspace Hub, Smart Home, and Personal Workspace.

---

## 2. Understanding Android Build Stages (Important Distinction)

| Artifact Type | What It Is | Can You Install It Directly on a Phone? |
| :--- | :--- | :--- |
| **1. Android Project `.zip` (This Download)** | Complete Kotlin, Compose, Manifest, Gradle & Brand Vector source project. | **Not directly** — compile it into an `.apk` first using Android Studio or the included GitHub Actions workflow. |
| **2. Debug `.apk` (`app-debug.apk`)** | Installable Android application package signed with a debug key. | **Yes** — transfer to your Android phone and tap to install for personal testing, or run via USB Debugging. |
| **3. Signed Internal Test Build (`.aab` / `.apk`)** | Signed with your private upload keystore (`upload-keystore.jks`). | **Yes** — upload to **Google Play Console -> Internal Testing** to install securely on up to 100 tester phones via Google Play. |
| **4. Google Play Production Release (`.aab`)** | Signed release Android App Bundle (`app-release.aab`). | **Yes (Public)** — requires Google Play Developer verification, Privacy Policy URL, Data Safety form, and store review. |

---

## 3. How to Build an Installable `.apk` on Your Computer (Android Studio)

1. Install **Android Studio Ladybug (2024.2.1+)** or newer (includes JDK 17 and Android SDK 35).
2. Unzip `lumi-ai-native-android-project.zip` and open the `lumi-ai-android` folder in Android Studio.
3. Wait for Gradle Sync to finish downloading dependencies.
4. *(Optional)* In `app/build.gradle.kts` (or `gradle.properties`), set `LUMI_BACKEND_URL=https://your-deployed-lumi-url.run.app` so the mobile app points to your live LUMI AI server.
5. Connect your Android phone via USB (with **Developer Options -> USB Debugging** enabled) and click **Run ▶**, **OR** choose **Build -> Build Bundle(s) / APK(s) -> Build APK(s)** to generate `app/build/outputs/apk/debug/app-debug.apk`.

### Alternative: Build `.apk` Without Installing Android Studio (GitHub Actions)
1. Push the unzipped `lumi-ai-android` folder to a private GitHub repository.
2. Open the **Actions** tab on GitHub and run **Build LUMI AI Android APK & Play Store AAB** (`.github/workflows/build-android-apk.yml`).
3. Download the compiled `lumi-ai-debug-apk` artifact directly to your Android phone.

---

## 4. Google Play Store Publication Checklist

Before submitting LUMI AI to Google Play Production:
1. **Google Play Console Account**: Register at [play.google.com/console](https://play.google.com/console) ($25 one-time fee) and complete developer identity verification.
2. **Upload Keystore**: In Android Studio, select **Build -> Generate Signed App Bundle / APK -> Android App Bundle**, create `lumi-upload-key.jks`, and back it up safely offline.
3. **Google OAuth Android Client SHA-1** *(if using native Google Sign-In)*: Run `./gradlew signingReport` and add your debug and release **SHA-1** certificate fingerprints in Google Cloud Console (`APIs & Services -> Credentials`) for `com.okolojoyce.lumiai`.
4. **Store Listing & Policy Compliance**:
   - Upload 512x512 high-res Lumi Beacon icon, 1024x500 feature graphic, and phone/tablet screenshots.
   - Provide a public HTTPS Privacy Policy URL disclosing `RECORD_AUDIO` (foreground voice commands) and optional Google Workspace scopes.
   - Complete the Google Play Data Safety & Content Rating questionnaires and roll out to **Internal Testing** before **Production**.
