package com.okolojoyce.lumiai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

enum class LumiVoiceState {
    WAITING,
    LISTENING,
    PROCESSING,
    SPEAKING
}

/**
 * Native Android Voice-First Manager for LUMI AI.
 * - Uses Android SpeechRecognizer for foreground tap-to-speak & barge-in interruption.
 * - Uses Android TextToSpeech for spoken replies, interruption, and replay.
 * - Does NOT claim silent background wake-word listening (which would require a persistent
 *   foreground microphone service + user notification under Android 14+ privacy rules).
 */
class LumiVoiceManager(
    private val context: Context,
    private val onFinalTranscript: (String) -> Unit,
    private val onErrorNotice: (String) -> Unit
) {
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var lastSpokenText: String = ""

    private val _voiceState = MutableStateFlow(LumiVoiceState.WAITING)
    val voiceState: StateFlow<LumiVoiceState> = _voiceState

    private val _partialTranscript = MutableStateFlow("")
    val partialTranscript: StateFlow<String> = _partialTranscript

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.UK
                ttsReady = true
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _voiceState.value = LumiVoiceState.SPEAKING
                    }

                    override fun onDone(utteranceId: String?) {
                        _voiceState.value = LumiVoiceState.WAITING
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _voiceState.value = LumiVoiceState.WAITING
                    }

                    override fun onStop(utteranceId: String?, interrupted: Boolean) {
                        if (_voiceState.value == LumiVoiceState.SPEAKING) {
                            _voiceState.value = LumiVoiceState.WAITING
                        }
                    }
                })
            }
        }
    }

    fun setProcessing() {
        _voiceState.value = LumiVoiceState.PROCESSING
    }

    fun setWaiting() {
        _voiceState.value = LumiVoiceState.WAITING
    }

    fun startListening(localeTag: String = "en-NG") {
        stopSpeaking()
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onErrorNotice("Speech recognition service is not available on this Android device.")
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _partialTranscript.value = ""
                    _voiceState.value = LumiVoiceState.LISTENING
                }

                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    _voiceState.value = LumiVoiceState.PROCESSING
                }

                override fun onError(error: Int) {
                    _voiceState.value = LumiVoiceState.WAITING
                    _partialTranscript.value = ""
                    val message = when (error) {
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                            "Microphone permission is required. Please grant RECORD_AUDIO access."
                        SpeechRecognizer.ERROR_NO_MATCH ->
                            "No speech detected. Tap the microphone and speak clearly."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                            "Network error during speech recognition. Check your internet connection."
                        else -> "Voice input stopped (code $error). Tap mic to try again."
                    }
                    onErrorNotice(message)
                }

                override fun onResults(results: Bundle?) {
                    _partialTranscript.value = ""
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val transcript = matches?.firstOrNull()?.trim().orEmpty()
                    if (transcript.isNotEmpty()) {
                        _voiceState.value = LumiVoiceState.PROCESSING
                        onFinalTranscript(transcript)
                    } else {
                        _voiceState.value = LumiVoiceState.WAITING
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        ?.trim()
                        .orEmpty()
                    if (partial.isNotEmpty()) {
                        _partialTranscript.value = partial
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        speechRecognizer?.startListening(intent)
    }

    fun stopListening() {
        speechRecognizer?.stopListening()
        _partialTranscript.value = ""
        if (_voiceState.value == LumiVoiceState.LISTENING) {
            _voiceState.value = LumiVoiceState.WAITING
        }
    }

    fun speak(rawMarkdown: String) {
        val clean = rawMarkdown
            .replace(Regex("```[\\s\\S]*?```"), " Interactive code artifact generated. ")
            .replace(Regex("[*#_`~>]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(900)

        if (clean.isEmpty() || !ttsReady) return
        lastSpokenText = clean
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "lumi_utt_${System.currentTimeMillis()}")
    }

    fun stopSpeaking() {
        tts?.stop()
        if (_voiceState.value == LumiVoiceState.SPEAKING) {
            _voiceState.value = LumiVoiceState.WAITING
        }
    }

    fun interruptAndListen(localeTag: String = "en-NG") {
        stopSpeaking()
        startListening(localeTag)
    }

    fun replayLastAnswer() {
        if (lastSpokenText.isNotEmpty() && ttsReady) {
            tts?.speak(
                lastSpokenText,
                TextToSpeech.QUEUE_FLUSH,
                null,
                "lumi_replay_${System.currentTimeMillis()}"
            )
        }
    }

    fun hasReplayableAnswer(): Boolean = lastSpokenText.isNotEmpty()

    fun shutdown() {
        speechRecognizer?.destroy()
        speechRecognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
