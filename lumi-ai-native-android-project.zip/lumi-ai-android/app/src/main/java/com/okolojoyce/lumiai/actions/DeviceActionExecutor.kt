package com.okolojoyce.lumiai.actions

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings

data class AndroidCommandReceipt(
    val matched: Boolean,
    val title: String = "",
    val detail: String = "",
    val forceWebSearch: Boolean = false
)

/**
 * Safe, extensible Android Intent & PackageManager command executor for LUMI AI.
 *
 * SAFETY GUARANTEES:
 * 1. Checks PackageManager before launching any external app and falls back cleanly to HTTPS browser URL if uninstalled.
 * 2. Never auto-sends WhatsApp messages or emails without the user tapping Send in the target app.
 * 3. Uses official Android AlarmClock & Settings intents rather than hidden private APIs.
 */
object DeviceActionExecutor {

    private data class AppTarget(
        val keywords: List<String>,
        val label: String,
        val packages: List<String>,
        val fallbackWebUrl: String
    )

    private val SUPPORTED_APPS = listOf(
        AppTarget(
            keywords = listOf("whatsapp"),
            label = "WhatsApp",
            packages = listOf("com.whatsapp", "com.whatsapp.w4b"),
            fallbackWebUrl = "https://web.whatsapp.com"
        ),
        AppTarget(
            keywords = listOf("youtube"),
            label = "YouTube",
            packages = listOf("com.google.android.youtube"),
            fallbackWebUrl = "https://www.youtube.com"
        ),
        AppTarget(
            keywords = listOf("gmail", "my email"),
            label = "Gmail",
            packages = listOf("com.google.android.gm"),
            fallbackWebUrl = "https://mail.google.com"
        ),
        AppTarget(
            keywords = listOf("google calendar", "my calendar", "calendar"),
            label = "Google Calendar",
            packages = listOf("com.google.android.calendar"),
            fallbackWebUrl = "https://calendar.google.com"
        ),
        AppTarget(
            keywords = listOf("google drive", "my drive"),
            label = "Google Drive",
            packages = listOf("com.google.android.apps.docs"),
            fallbackWebUrl = "https://drive.google.com"
        ),
        AppTarget(
            keywords = listOf("google contacts", "my contacts", "contacts"),
            label = "Google Contacts",
            packages = listOf("com.google.android.contacts"),
            fallbackWebUrl = "https://contacts.google.com"
        ),
        AppTarget(
            keywords = listOf("my browser", "browser", "chrome"),
            label = "Browser",
            packages = listOf("com.android.chrome"),
            fallbackWebUrl = "https://www.google.com"
        ),
        AppTarget(
            keywords = listOf("google"),
            label = "Google",
            packages = listOf("com.google.android.googlequicksearchbox"),
            fallbackWebUrl = "https://www.google.com"
        )
    )

    fun evaluateAndExecuteIfDeviceCommand(context: Context, rawText: String): AndroidCommandReceipt {
        val normalized = rawText
            .trim()
            .replace(Regex("^(?:hey\\s+|hi\\s+|ok\\s+|okay\\s+)?lumi[\\s,.:!-]*", RegexOption.IGNORE_CASE), "")
            .replace(Regex("^(?:please|kindly|can you|could you)\\s+", RegexOption.IGNORE_CASE), "")
            .trim()

        if (normalized.isEmpty()) return AndroidCommandReceipt(matched = false)
        val lower = normalized.lowercase()

        // 1. Open Android System Settings
        if (Regex("^(?:open|launch|go to)\\s+(?:my\\s+|phone\\s+|device\\s+)?settings$").matches(lower)) {
            return try {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                AndroidCommandReceipt(
                    matched = true,
                    title = "Opened Android Settings",
                    detail = "Launched android.settings.SETTINGS via safe system Intent."
                )
            } catch (e: Exception) {
                AndroidCommandReceipt(
                    matched = true,
                    title = "Could not open Settings",
                    detail = e.localizedMessage ?: "Settings Intent unavailable."
                )
            }
        }

        // 2. Open Known Installed App (WhatsApp, YouTube, Gmail, Calendar, Drive, Contacts, Browser, Google)
        if (lower.startsWith("open ") || lower.startsWith("launch ")) {
            val targetPhrase = lower.removePrefix("open ").removePrefix("launch ").trim()
            val match = SUPPORTED_APPS.firstOrNull { app ->
                app.keywords.any { kw -> targetPhrase.contains(kw) }
            }
            if (match != null) {
                val pm = context.packageManager
                for (pkg in match.packages) {
                    val launchIntent = pm.getLaunchIntentForPackage(pkg)
                    if (launchIntent != null) {
                        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(launchIntent)
                        return AndroidCommandReceipt(
                            matched = true,
                            title = "Launched ${match.label}",
                            detail = "Verified package ($pkg) via PackageManager and opened ${match.label}."
                        )
                    }
                }
                // Honest fallback if app is not installed on device
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(match.fallbackWebUrl)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                return try {
                    context.startActivity(browserIntent)
                    AndroidCommandReceipt(
                        matched = true,
                        title = "${match.label} App Not Installed — Opened Web Fallback",
                        detail = "${match.label} (${match.packages.first()}) was not found on this device; opened ${match.fallbackWebUrl} in your browser."
                    )
                } catch (e: Exception) {
                    AndroidCommandReceipt(
                        matched = true,
                        title = "${match.label} Unavailable",
                        detail = "${match.label} is not installed and no browser handler was found."
                    )
                }
            }
        }

        // 3. Set a Reminder / Timer via Android AlarmClock Intent
        val reminderRegex = Regex("^(?:set a reminder|remind me)(?:\\s+to|\\s+about)?\\s*(.*)$", RegexOption.IGNORE_CASE)
        val remMatch = reminderRegex.find(normalized)
        if (remMatch != null) {
            val messageTitle = remMatch.groupValues.getOrNull(1)?.trim().takeUnless { it.isNullOrEmpty() }
                ?: "Lumi AI Reminder"
            val minMatch = Regex("\\bin\\s+(\\d+)\\s*(?:min|minute|minutes)\\b", RegexOption.IGNORE_CASE).find(messageTitle)
            if (minMatch != null) {
                val minutes = minMatch.groupValues[1].toIntOrNull() ?: 5
                val timerIntent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                    putExtra(AlarmClock.EXTRA_LENGTH, minutes * 60)
                    putExtra(AlarmClock.EXTRA_MESSAGE, messageTitle)
                    putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                return try {
                    context.startActivity(timerIntent)
                    AndroidCommandReceipt(
                        matched = true,
                        title = "Opened Android Timer ($minutes min)",
                        detail = "Prepared \"$messageTitle\" in your device Clock app for confirmation."
                    )
                } catch (_: Exception) {
                    AndroidCommandReceipt(
                        matched = true,
                        title = "Reminder Noted",
                        detail = "Clock timer handler unavailable; Lumi noted \"$messageTitle\" in chat."
                    )
                }
            }
        }

        // 4. Explicit Live Web Search routing
        if (lower.startsWith("search the web for ") || lower.startsWith("search google for ") || lower.startsWith("look up online ")) {
            return AndroidCommandReceipt(
                matched = true,
                title = "Live Google Search Grounding",
                detail = "Routing query through Lumi's grounded Google Search endpoint with source citations.",
                forceWebSearch = true
            )
        }

        return AndroidCommandReceipt(matched = false)
    }

    /**
     * Opens Android Share / WhatsApp composer with pre-filled draft text.
     * Never sends automatically — the user reviews the recipient and taps Send.
     */
    fun shareDraftSafely(context: Context, draftText: String) {
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, draftText)
        }
        val chooser = Intent.createChooser(sendIntent, "Share Lumi Draft (Review before sending)").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }
}
