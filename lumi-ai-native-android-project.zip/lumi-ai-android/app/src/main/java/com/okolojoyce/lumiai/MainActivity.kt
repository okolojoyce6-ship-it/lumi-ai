package com.okolojoyce.lumiai

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.okolojoyce.lumiai.actions.AndroidCommandReceipt
import com.okolojoyce.lumiai.actions.DeviceActionExecutor
import com.okolojoyce.lumiai.network.GroundingCitation
import com.okolojoyce.lumiai.network.LumiApiClient
import com.okolojoyce.lumiai.voice.LumiVoiceManager
import com.okolojoyce.lumiai.voice.LumiVoiceState
import kotlinx.coroutines.launch

private val LumiNavyDeep = Color(0xFF060B18)
private val LumiNavyCard = Color(0xFF0C172E)
private val LumiGold = Color(0xFFE5C158)
private val LumiGoldBright = Color(0xFFF5D061)
private val LumiWhite = Color(0xFFFFFFFF)

data class NativeChatMessage(
    val id: String,
    val role: String,
    val text: String,
    val receipt: AndroidCommandReceipt? = null,
    val citations: List<GroundingCitation> = emptyList(),
    val searchGrounded: Boolean = false
)

class MainActivity : ComponentActivity() {

    private lateinit var voiceManager: LumiVoiceManager

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        var externalSendTrigger: ((String) -> Unit)? = null
        var externalErrorTrigger: ((String) -> Unit)? = null

        voiceManager = LumiVoiceManager(
            context = this,
            onFinalTranscript = { spoken -> externalSendTrigger?.invoke(spoken) },
            onErrorNotice = { err -> externalErrorTrigger?.invoke(err) }
        )

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = LumiGold,
                    background = LumiNavyDeep,
                    surface = LumiNavyCard,
                    onPrimary = LumiNavyDeep,
                    onBackground = LumiWhite,
                    onSurface = LumiWhite
                )
            ) {
                LumiNativeAppScreen(
                    voiceManager = voiceManager,
                    bindCallbacks = { onSend, onErr ->
                        externalSendTrigger = onSend
                        externalErrorTrigger = onErr
                    }
                )
            }
        }
    }

    override fun onDestroy() {
        voiceManager.shutdown()
        super.onDestroy()
    }
}

@Composable
fun LumiNativeAppScreen(
    voiceManager: LumiVoiceManager,
    bindCallbacks: ((String) -> Unit, (String) -> Unit) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val voiceState by voiceManager.voiceState.collectAsState()
    val partialTranscript by voiceManager.partialTranscript.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Native Voice & Actions, 1 = Full Web Workspace
    var inputText by remember { mutableStateOf("") }
    var liveWebSearchEnabled by remember { mutableStateOf(true) }
    var autoSpeakReplies by remember { mutableStateOf(true) }
    var errorBanner by remember { mutableStateOf<String?>(null) }

    val messages = remember {
        mutableStateListOf(
            NativeChatMessage(
                id = "welcome",
                role = "assistant",
                text = "Hello! I'm LUMI AI — Your World, Intelligently Connected.\n\nTap the gold microphone to speak naturally, ask me to open WhatsApp, YouTube, Gmail, Calendar, or Settings, set a reminder, or search the live web with citations."
            )
        )
    }

    fun dispatchPrompt(rawPrompt: String, spokenInput: Boolean = false) {
        val clean = rawPrompt.trim()
        if (clean.isEmpty()) return
        errorBanner = null

        val cmdReceipt = DeviceActionExecutor.evaluateAndExecuteIfDeviceCommand(context, clean)
        messages.add(
            NativeChatMessage(
                id = "u_${System.currentTimeMillis()}",
                role = "user",
                text = clean
            )
        )

        voiceManager.setProcessing()
        scope.launch {
            val historyPairs = messages.map { it.role to it.text }
            val useSearch = liveWebSearchEnabled || cmdReceipt.forceWebSearch
            val res = LumiApiClient.sendChatMessage(
                history = historyPairs,
                enableSearch = useSearch
            )

            res.onSuccess { payload ->
                messages.add(
                    NativeChatMessage(
                        id = "a_${System.currentTimeMillis()}",
                        role = "assistant",
                        text = payload.reply,
                        receipt = if (cmdReceipt.matched) cmdReceipt else null,
                        citations = payload.citations,
                        searchGrounded = payload.searchExecuted
                    )
                )
                voiceManager.setWaiting()
                if (autoSpeakReplies || spokenInput) {
                    voiceManager.speak(payload.reply)
                }
            }.onFailure { err ->
                voiceManager.setWaiting()
                errorBanner = err.localizedMessage ?: "Could not reach Lumi AI backend."
            }
        }
    }

    LaunchedEffect(Unit) {
        bindCallbacks(
            { transcript -> dispatchPrompt(transcript, spokenInput = true) },
            { err -> errorBanner = err }
        )
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            voiceManager.startListening()
        } else {
            errorBanner = "Microphone permission denied. Enable RECORD_AUDIO in Android Settings to use voice."
        }
    }

    fun requestOrToggleMic() {
        if (voiceState == LumiVoiceState.LISTENING) {
            voiceManager.stopListening()
            return
        }
        val hasPerm = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (hasPerm) {
            voiceManager.startListening()
        } else {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    Scaffold(
        containerColor = LumiNavyDeep,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(LumiNavyCard)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "LUMI ",
                            color = LumiWhite,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "AI",
                            color = LumiGoldBright,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp
                        )
                    }
                    Text(
                        text = "Your World, Intelligently Connected.",
                        color = Color(0xFF94A3B8),
                        fontSize = 11.sp
                    )
                }

                // Explicit 4-State Voice Status Indicator
                val stateLabel = when (voiceState) {
                    LumiVoiceState.LISTENING -> "LISTENING"
                    LumiVoiceState.PROCESSING -> "PROCESSING"
                    LumiVoiceState.SPEAKING -> "SPEAKING"
                    LumiVoiceState.WAITING -> "WAITING"
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(LumiGold.copy(alpha = 0.14f))
                        .border(1.dp, LumiGold.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = stateLabel,
                        color = LumiGoldBright,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = LumiNavyCard) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Mic, contentDescription = "Companion") },
                    label = { Text("Voice & Device") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Public, contentDescription = "Full Workspace") },
                    label = { Text("Full Workspace") }
                )
            }
        }
    ) { innerPadding ->
        if (selectedTab == 1) {
            LumiFullWorkspaceWebView(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            )
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 14.dp)
            ) {
                // Voice Interruption & Replay Strip
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = liveWebSearchEnabled,
                        onClick = { liveWebSearchEnabled = !liveWebSearchEnabled },
                        label = { Text("Web Search", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = autoSpeakReplies,
                        onClick = { autoSpeakReplies = !autoSpeakReplies },
                        label = { Text("Spoken Replies", fontSize = 11.sp) }
                    )
                    if (voiceState == LumiVoiceState.SPEAKING) {
                        AssistChip(
                            onClick = { voiceManager.interruptAndListen() },
                            label = { Text("Interrupt & Speak", fontSize = 11.sp, color = LumiGoldBright) }
                        )
                    } else if (voiceManager.hasReplayableAnswer()) {
                        AssistChip(
                            onClick = { voiceManager.replayLastAnswer() },
                            label = { Text("Replay", fontSize = 11.sp) }
                        )
                    }
                }

                if (partialTranscript.isNotBlank()) {
                    Text(
                        text = "Hearing: \"$partialTranscript\"",
                        color = LumiGoldBright,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }

                errorBanner?.let { err ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF4C0519))
                            .padding(10.dp)
                    ) {
                        Text(text = err, color = Color(0xFFFECDD3), fontSize = 12.sp)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    items(messages, key = { it.id }) { msg ->
                        val isUser = msg.role == "user"
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
                        ) {
                            Box(
                                modifier = Modifier
                                    .widthIn(max = 320.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(
                                        if (isUser) Brush.horizontalGradient(listOf(LumiGoldBright, LumiGold))
                                        else Brush.horizontalGradient(listOf(LumiNavyCard, LumiNavyCard))
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (isUser) Color.Transparent else LumiGold.copy(alpha = 0.25f),
                                        shape = RoundedCornerShape(16.dp)
                                    )
                                    .padding(12.dp)
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(
                                        text = msg.text,
                                        color = if (isUser) LumiNavyDeep else LumiWhite,
                                        fontSize = 14.sp
                                    )

                                    msg.receipt?.let { rec ->
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(LumiNavyDeep)
                                                .padding(8.dp)
                                        ) {
                                            Text(
                                                text = rec.title,
                                                color = LumiGoldBright,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp
                                            )
                                            Text(
                                                text = rec.detail,
                                                color = Color(0xFFCBD5E1),
                                                fontSize = 11.sp
                                            )
                                        }
                                    }

                                    if (msg.citations.isNotEmpty()) {
                                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text(
                                                text = "Verified Google Search Sources:",
                                                color = Color(0xFF6EE7B7),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                            msg.citations.take(4).forEach { cite ->
                                                Text(
                                                    text = "• ${cite.title} (${cite.domain})",
                                                    color = LumiGoldBright,
                                                    fontSize = 11.sp,
                                                    modifier = Modifier.clickable {
                                                        val browserIntent = Intent(
                                                            Intent.ACTION_VIEW,
                                                            Uri.parse(cite.uri)
                                                        )
                                                        context.startActivity(browserIntent)
                                                    }
                                                )
                                            }
                                        }
                                    }

                                    if (!isUser) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                            Text(
                                                text = "Speak",
                                                color = LumiGold,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                modifier = Modifier.clickable { voiceManager.speak(msg.text) }
                                            )
                                            Text(
                                                text = "Share Draft",
                                                color = LumiGold,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                modifier = Modifier.clickable {
                                                    DeviceActionExecutor.shareDraftSafely(context, msg.text)
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Bottom Voice-First & Text Composer Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = { requestOrToggleMic() },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(
                                if (voiceState == LumiVoiceState.LISTENING) Color(0xFFE11D48)
                                else LumiGold
                            )
                    ) {
                        Icon(
                            imageVector = if (voiceState == LumiVoiceState.LISTENING) Icons.Default.Stop else Icons.Default.Mic,
                            contentDescription = "Tap to Speak",
                            tint = if (voiceState == LumiVoiceState.LISTENING) LumiWhite else LumiNavyDeep
                        )
                    }

                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = { Text("Ask Lumi or give a command...", fontSize = 13.sp) },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )

                    IconButton(
                        onClick = {
                            val toSend = inputText
                            inputText = ""
                            dispatchPrompt(toSend)
                        },
                        enabled = inputText.isNotBlank() && voiceState != LumiVoiceState.PROCESSING,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(LumiGoldBright)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send",
                            tint = LumiNavyDeep
                        )
                    }
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LumiFullWorkspaceWebView(modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                webViewClient = WebViewClient()
                loadUrl(BuildConfig.LUMI_BACKEND_URL)
            }
        }
    )
}
