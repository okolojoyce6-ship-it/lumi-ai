package com.okolojoyce.lumiai.network

import com.okolojoyce.lumiai.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class GroundingCitation(
    val title: String,
    val uri: String,
    val domain: String
)

data class LumiReplyPayload(
    val reply: String,
    val searchExecuted: Boolean = false,
    val citations: List<GroundingCitation> = emptyList(),
    val fallbackNotice: String? = null
)

/**
 * Secure Backend Client for LUMI AI Android App.
 * Connects to the Lumi AI Express/Cloud Run backend (`/api/chat` and `/api/search`)
 * so `GEMINI_API_KEY` stays strictly server-side and is never embedded in the Android APK.
 */
object LumiApiClient {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun sendChatMessage(
        history: List<Pair<String, String>>,
        enableSearch: Boolean,
        userName: String = "Friend"
    ): Result<LumiReplyPayload> = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = BuildConfig.LUMI_BACKEND_URL.trimEnd('/')
            val messagesArray = JSONArray()
            history.takeLast(16).forEach { (role, content) ->
                messagesArray.put(
                    JSONObject().apply {
                        put("role", role)
                        put("content", content)
                    }
                )
            }

            val payload = JSONObject().apply {
                put("messages", messagesArray)
                put("mode", "casual")
                put("languagePreference", "auto")
                put("userName", userName)
                put("enableSearch", enableSearch)
            }

            val request = Request.Builder()
                .url("$baseUrl/api/chat")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            httpClient.newCall(request).execute().use { response ->
                val rawBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val errMsg = runCatching { JSONObject(rawBody).optString("error") }
                        .getOrNull()
                        .takeUnless { it.isNullOrBlank() }
                        ?: "Server returned HTTP ${response.code}"
                    throw IllegalStateException(errMsg)
                }

                val json = JSONObject(rawBody)
                val replyText = json.optString("reply", "")
                val groundingObj = json.optJSONObject("grounding")
                val searchExecuted = groundingObj?.optBoolean("searchExecuted", false) ?: false
                val fallbackNotice = groundingObj?.optString("fallbackNotice")?.takeIf { it.isNotBlank() }

                val citations = mutableListOf<GroundingCitation>()
                val sourcesArr = groundingObj?.optJSONArray("sources")
                if (sourcesArr != null) {
                    for (i in 0 until sourcesArr.length()) {
                        val item = sourcesArr.optJSONObject(i) ?: continue
                        val uri = item.optString("uri")
                        if (uri.isNotBlank()) {
                            citations.add(
                                GroundingCitation(
                                    title = item.optString("title", "Web Source"),
                                    uri = uri,
                                    domain = item.optString("domain", uri)
                                )
                            )
                        }
                    }
                }

                LumiReplyPayload(
                    reply = replyText,
                    searchExecuted = searchExecuted,
                    citations = citations,
                    fallbackNotice = fallbackNotice
                )
            }
        }
    }
}
